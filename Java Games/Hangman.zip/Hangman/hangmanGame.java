import java.util.*;
import java.io.*;


public class hangmanGame{
	public static void main(String[] args){
		Scanner scanner = new Scanner(System.in);

		Random random = new Random();

		System.out.println("");
		System.out.println("-----------------------------");
		System.out.println("Welcome to Hangman");
		System.out.println("-----------------------------");

		System.out.println("");
		System.out.println("");
		System.out.println("");

		System.out.println("Choose a mode");
		System.out.println("|EASY|   You will have to guess letters less than 6");
		System.out.println("");
		System.out.println("|MEDIUM| You will have to guess letters between 6 to 10");
		System.out.println("");
		System.out.println("|HARD|   You will have to guess letters more than 10");

		String easy[] = new String[5500];
		String medium[] = new String[5500];
		String hard[] = new String[5500];
		String guesses[] = new String[5449];
		String s = "";
		int k = 0;

		try{
				Scanner inFile1 = new Scanner(new File("Words.txt"));

				String userMode = scanner.nextLine();

				String userMode1 = userMode.toLowerCase();
				//Treating the lowercase and uppercase input from user as same



	

		while (inFile1.hasNext() && k < 5500){
			s = inFile1.next();
			guesses[k] = s;
			k++;
			
		}



		//making a new arrays as per the length of words 
		for(int j = 0; j < guesses.length;j++){
		if(guesses[j].length() < 6){
			easy[j] = guesses[j];		
		}
		else if(guesses[j].length() >= 6 && guesses[j].length() <=10){
			medium[j] = guesses[j];
		}	
		else if(guesses[j].length() > 10){
			hard[j] = guesses[j];
		}
	}
	

			if(userMode1.equals("easy")){
				System.out.println("You have selected easy mode Good luck!");

		boolean gamePlaying = true;

		while(gamePlaying){
			

			


			
		

			char[] randomWordToGuess = guesses[random.nextInt(guesses.length)].toCharArray();
			//It randomly selects the word from the array guess, tocharArray breaks down the string into single characters
			int amountOfGuesses = randomWordToGuess.length;
			//It will tell the length of the word to be guessed
			char[] playerGuess = new char[amountOfGuesses];
			


			for (int i =0;i < playerGuess.length;i++){
				playerGuess[i] = '_';
				
			}

			

			
			
				
			
			// We will get the _ _ required for the game
			boolean wordIsGuessed = false;
			//if this is true then the game is won
			int tries = 0;
			//to check the no of tries of user

			while(!wordIsGuessed && tries!= amountOfGuesses){




				//when the word is not guessed and we still have tries left not exceeding the amount of guess
				System.out.print("Current guesses:");
				printArray(playerGuess);
				System.out.printf("You have %d tries left.\n",amountOfGuesses - tries);
				//THIS HELPS THE USER TO KNOW HOW MANY TRIES LEFT
				System.out.println("Enter a single character");
				char input = scanner.nextLine().charAt(0);
				System.out.println(input);
				//WE TAKE THE INPUT FROM USER EVEN IF THEY ENTER A WORD IT WILL ONLY TAKE A CHARACTER
				tries++;
				//INCREASE THE NO OF TRIES EACH TIME WE GET INPUT


				if(input == '-'){
					//IF THE USER ENTERS - THE GAME WILL EXIST AS WE ASSUME THE WORD IS GUESSED
					gamePlaying = false;
					wordIsGuessed = true;
				}
				else{
					for (int i = 0;i< randomWordToGuess.length;i++) {
						if(randomWordToGuess[i] == input){
							playerGuess[i] = input;
							// WE REPLACE THE _ WITH THE CORRECT GUESS
						}
						
					}// END OF FOR LOOP

					if(isTheWordGuessed(playerGuess)){
						wordIsGuessed = true;
						System.out.println("you won");
						//IF THE USER COMPLETES THE WORD WITH CORRECT GUESS THEN THE GAME IS COMPLETED
					}
				}

			

			}
				if(!wordIsGuessed) 	
				//IF WE RUN OUT OF GUESSES
				System.out.println("out of guess");
				System.out.println("Correct Word was:");
				System.out.println(randomWordToGuess);
				System.out.println("Do you want to play again yes/no");
				String anotherGame = scanner.nextLine();
				//IF THE USER DOESN'T WANTS TO PLAY THEN HE CAN LEAVEBY PRESSING NO
				if(anotherGame.equals("no")) gamePlaying = false;
}


		}//end of easy




		if(userMode1.equals("medium")){
				System.out.println("You have selected medium mode Good luck!");

		boolean gamePlaying = true;

		while(gamePlaying){
			

			


			
		

			char[] randomWordToGuess = easy[random.nextInt(guesses.length)].toCharArray();
			//It randomly selects the word from the array guess, tocharArray breaks down the string into single characters
			int amountOfGuesses = randomWordToGuess.length;
			//It will tell the length of the word to be guessed
			char[] playerGuess = new char[amountOfGuesses];
			


			for (int i =0;i < playerGuess.length;i++){
				playerGuess[i] = '_';
				
			}

			

			
			
				
			
			// We will get the _ _ required for the game
			boolean wordIsGuessed = false;
			//if this is true then the game is won
			int tries = 0;
			//to check the no of tries of user

			while(!wordIsGuessed && tries!= amountOfGuesses){




				//when the word is not guessed and we still have tries left not exceeding the amount of guess
				System.out.print("Current guesses:");
				printArray(playerGuess);
				System.out.printf("You have %d tries left.\n",amountOfGuesses - tries);
				//THIS HELPS THE USER TO KNOW HOW MANY TRIES LEFT
				System.out.println("Enter a single character");
				char input = scanner.nextLine().charAt(0);
				//WE TAKE THE INPUT FROM USER EVEN IF THEY ENTER A WORD IT WILL ONLY TAKE A CHARACTER
				tries++;
				//INCREASE THE NO OF TRIES EACH TIME WE GET INPUT


				if(input == '-'){
					//IF THE USER ENTERS - THE GAME WILL EXIST AS WE ASSUME THE WORD IS GUESSED
					gamePlaying = false;
					wordIsGuessed = true;
				}
				else{
					for (int i = 0;i< randomWordToGuess.length;i++) {
						if(randomWordToGuess[i] == input){
							playerGuess[i] = input;
							// WE REPLACE THE _ WITH THE CORRECT GUESS
						}
						
					}// END OF FOR LOOP

					if(isTheWordGuessed(playerGuess)){
						wordIsGuessed = true;
						System.out.println("you won");
						//IF THE USER COMPLETES THE WORD WITH CORRECT GUESS THEN THE GAME IS COMPLETED
					}
				}

			

			}
				if(!wordIsGuessed) 	
				//IF WE RUN OUT OF GUESSES
				System.out.println("out of guess");
				System.out.println("Correct Word was:");
				System.out.println(randomWordToGuess);
				System.out.println("Do you want to play again yes/no");
				String anotherGame = scanner.nextLine();
				//IF THE USER DOESN'T WANTS TO PLAY THEN HE CAN LEAVEBY PRESSING NO
				if(anotherGame.equals("no")) gamePlaying = false;
}


		}//end of medium

		if(userMode1.equals("hard")){
				System.out.println("You have selected easy hard Good luck!");

		boolean gamePlaying = true;

		while(gamePlaying){
			

			


			
		

			char[] randomWordToGuess = easy[random.nextInt(guesses.length)].toCharArray();
			//It randomly selects the word from the array guess, tocharArray breaks down the string into single characters
			int amountOfGuesses = randomWordToGuess.length;
			//It will tell the length of the word to be guessed
			char[] playerGuess = new char[amountOfGuesses];
			


			for (int i =0;i < playerGuess.length;i++){
				playerGuess[i] = '_';
				
			}

			

			
			
				
			
			// We will get the _ _ required for the game
			boolean wordIsGuessed = false;
			//if this is true then the game is won
			int tries = 0;
			//to check the no of tries of user

			while(!wordIsGuessed && tries!= amountOfGuesses){




				//when the word is not guessed and we still have tries left not exceeding the amount of guess
				System.out.print("Current guesses:");
				printArray(playerGuess);
				System.out.printf("You have %d tries left.\n",amountOfGuesses - tries);
				//THIS HELPS THE USER TO KNOW HOW MANY TRIES LEFT
				System.out.println("Enter a single character");
				char input = scanner.nextLine().charAt(0);
				//WE TAKE THE INPUT FROM USER EVEN IF THEY ENTER A WORD IT WILL ONLY TAKE A CHARACTER
				tries++;
				//INCREASE THE NO OF TRIES EACH TIME WE GET INPUT


				if(input == '-'){
					//IF THE USER ENTERS - THE GAME WILL EXIST AS WE ASSUME THE WORD IS GUESSED
					gamePlaying = false;
					wordIsGuessed = true;
				}
				else{
					for (int i = 0;i< randomWordToGuess.length;i++) {
						if(randomWordToGuess[i] == input){
							playerGuess[i] = input;
							// WE REPLACE THE _ WITH THE CORRECT GUESS
						}
						
					}// END OF FOR LOOP

					if(isTheWordGuessed(playerGuess)){
						wordIsGuessed = true;
						System.out.println("you won");
						//IF THE USER COMPLETES THE WORD WITH CORRECT GUESS THEN THE GAME IS COMPLETED
					}
				}

			

			}
				if(!wordIsGuessed) 	
				//IF WE RUN OUT OF GUESSES
				System.out.println("out of guess");
				System.out.println("Correct Word was:");
				System.out.println(randomWordToGuess);
				System.out.println("Do you want to play again yes/no");
				String anotherGame = scanner.nextLine();
				//IF THE USER DOESN'T WANTS TO PLAY THEN HE CAN LEAVEBY PRESSING NO
				if(anotherGame.equals("no")) gamePlaying = false;
}


		}//end of hard


		else
			System.out.println("Please select a valid mode");









	}//end of try mode
	

		catch(FileNotFoundException ex){}


		System.out.println("--------Game over-------------");
	}//end of main method






	public static void printArray(char[] array){
		for (int i=0;i< array.length;i++){
			System.out.print(array[i] + " ");

			
		}
		System.out.println("");
		//IT PRINTS THE ELEMENT IN THE ARRAY 

	}// END OF PRINTARRAY

public static boolean isTheWordGuessed(char[] array){
	for (int i = 0;i<array.length;i++) {
		if (array[i] == '_') 
			return false;
		
			
		} // END OF FOR LOOP
	return true;
	//IF WE DONT FIND ANY UNDERSCORE WE RETURN TRUE WHICH MEANS THE WORD IS GUESSED
}

}//end of hangman